<?php

do_action('mane_elated_action_style_dynamic');