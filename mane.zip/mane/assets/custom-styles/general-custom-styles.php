<?php

if(!function_exists('mane_elated_design_styles')) {
    /**
     * Generates general custom styles
     */
    function mane_elated_design_styles() {
	    $font_family = mane_elated_options()->getOptionValue( 'google_fonts' );
	    if ( ! empty( $font_family ) && mane_elated_is_font_option_valid( $font_family ) ) {
		    $font_family_selector = array(
			    'body'
		    );
		    echo mane_elated_dynamic_css( $font_family_selector, array( 'font-family' => mane_elated_get_font_option_val( $font_family ) ) );
	    }
	
	    $page_background_color = mane_elated_options()->getOptionValue( 'page_background_color' );
	    if ( ! empty( $page_background_color ) ) {
		    $background_color_selector = array(
			    'body',
			    '.eltdf-content'
		    );
		    echo mane_elated_dynamic_css( $background_color_selector, array( 'background-color' => $page_background_color ) );
	    }
	
	    $selection_color = mane_elated_options()->getOptionValue( 'selection_color' );
	    if ( ! empty( $selection_color ) ) {
		    echo mane_elated_dynamic_css( '::selection', array( 'background' => $selection_color ) );
		    echo mane_elated_dynamic_css( '::-moz-selection', array( 'background' => $selection_color ) );
	    }
	
	    $preload_background_styles = array();
	
	    if ( mane_elated_options()->getOptionValue( 'preload_pattern_image' ) !== "" ) {
		    $preload_background_styles['background-image'] = 'url(' . mane_elated_options()->getOptionValue( 'preload_pattern_image' ) . ') !important';
	    }
	
	    echo mane_elated_dynamic_css( '.eltdf-preload-background', $preload_background_styles );
    }

    add_action('mane_elated_action_style_dynamic', 'mane_elated_design_styles');
}

if ( ! function_exists( 'mane_elated_content_styles' ) ) {
	function mane_elated_content_styles() {
		$content_style = array();
		
		$padding_top = mane_elated_options()->getOptionValue( 'content_top_padding' );
		if ( $padding_top !== '' ) {
			$content_style['padding-top'] = mane_elated_filter_px( $padding_top ) . 'px';
		}
		
		$content_selector = array(
			'.eltdf-content .eltdf-content-inner > .eltdf-full-width > .eltdf-full-width-inner',
		);
		
		echo mane_elated_dynamic_css( $content_selector, $content_style );
		
		$content_style_in_grid = array();
		
		$padding_top_in_grid = mane_elated_options()->getOptionValue( 'content_top_padding_in_grid' );
		if ( $padding_top_in_grid !== '' ) {
			$content_style_in_grid['padding-top'] = mane_elated_filter_px( $padding_top_in_grid ) . 'px';
		}
		
		$content_selector_in_grid = array(
			'.eltdf-content .eltdf-content-inner > .eltdf-container > .eltdf-container-inner',
		);
		
		echo mane_elated_dynamic_css( $content_selector_in_grid, $content_style_in_grid );
	}
	
	add_action( 'mane_elated_action_style_dynamic', 'mane_elated_content_styles' );
}

if ( ! function_exists( 'mane_elated_h1_styles' ) ) {
	function mane_elated_h1_styles() {
		$margin_top    = mane_elated_options()->getOptionValue( 'h1_margin_top' );
		$margin_bottom = mane_elated_options()->getOptionValue( 'h1_margin_bottom' );
		
		$item_styles = mane_elated_get_typography_styles( 'h1' );
		
		if ( $margin_top !== '' ) {
			$item_styles['margin-top'] = mane_elated_filter_px( $margin_top ) . 'px';
		}
		if ( $margin_bottom !== '' ) {
			$item_styles['margin-bottom'] = mane_elated_filter_px( $margin_bottom ) . 'px';
		}
		
		$item_selector = array(
			'h1'
		);
		
		if ( ! empty( $item_styles ) ) {
			echo mane_elated_dynamic_css( $item_selector, $item_styles );
		}
	}
	
	add_action( 'mane_elated_action_style_dynamic', 'mane_elated_h1_styles' );
}

if ( ! function_exists( 'mane_elated_h2_styles' ) ) {
	function mane_elated_h2_styles() {
		$margin_top    = mane_elated_options()->getOptionValue( 'h2_margin_top' );
		$margin_bottom = mane_elated_options()->getOptionValue( 'h2_margin_bottom' );
		
		$item_styles = mane_elated_get_typography_styles( 'h2' );
		
		if ( $margin_top !== '' ) {
			$item_styles['margin-top'] = mane_elated_filter_px( $margin_top ) . 'px';
		}
		if ( $margin_bottom !== '' ) {
			$item_styles['margin-bottom'] = mane_elated_filter_px( $margin_bottom ) . 'px';
		}
		
		$item_selector = array(
			'h2'
		);
		
		if ( ! empty( $item_styles ) ) {
			echo mane_elated_dynamic_css( $item_selector, $item_styles );
		}
	}
	
	add_action( 'mane_elated_action_style_dynamic', 'mane_elated_h2_styles' );
}

if ( ! function_exists( 'mane_elated_h3_styles' ) ) {
	function mane_elated_h3_styles() {
		$margin_top    = mane_elated_options()->getOptionValue( 'h3_margin_top' );
		$margin_bottom = mane_elated_options()->getOptionValue( 'h3_margin_bottom' );
		
		$item_styles = mane_elated_get_typography_styles( 'h3' );
		
		if ( $margin_top !== '' ) {
			$item_styles['margin-top'] = mane_elated_filter_px( $margin_top ) . 'px';
		}
		if ( $margin_bottom !== '' ) {
			$item_styles['margin-bottom'] = mane_elated_filter_px( $margin_bottom ) . 'px';
		}
		
		$item_selector = array(
			'h3'
		);
		
		if ( ! empty( $item_styles ) ) {
			echo mane_elated_dynamic_css( $item_selector, $item_styles );
		}
	}
	
	add_action( 'mane_elated_action_style_dynamic', 'mane_elated_h3_styles' );
}

if ( ! function_exists( 'mane_elated_h4_styles' ) ) {
	function mane_elated_h4_styles() {
		$margin_top    = mane_elated_options()->getOptionValue( 'h4_margin_top' );
		$margin_bottom = mane_elated_options()->getOptionValue( 'h4_margin_bottom' );
		
		$item_styles = mane_elated_get_typography_styles( 'h4' );
		
		if ( $margin_top !== '' ) {
			$item_styles['margin-top'] = mane_elated_filter_px( $margin_top ) . 'px';
		}
		if ( $margin_bottom !== '' ) {
			$item_styles['margin-bottom'] = mane_elated_filter_px( $margin_bottom ) . 'px';
		}
		
		$item_selector = array(
			'h4'
		);
		
		if ( ! empty( $item_styles ) ) {
			echo mane_elated_dynamic_css( $item_selector, $item_styles );
		}
	}
	
	add_action( 'mane_elated_action_style_dynamic', 'mane_elated_h4_styles' );
}

if ( ! function_exists( 'mane_elated_h5_styles' ) ) {
	function mane_elated_h5_styles() {
		$margin_top    = mane_elated_options()->getOptionValue( 'h5_margin_top' );
		$margin_bottom = mane_elated_options()->getOptionValue( 'h5_margin_bottom' );
		
		$item_styles = mane_elated_get_typography_styles( 'h5' );
		
		if ( $margin_top !== '' ) {
			$item_styles['margin-top'] = mane_elated_filter_px( $margin_top ) . 'px';
		}
		if ( $margin_bottom !== '' ) {
			$item_styles['margin-bottom'] = mane_elated_filter_px( $margin_bottom ) . 'px';
		}
		
		$item_selector = array(
			'h5'
		);
		
		if ( ! empty( $item_styles ) ) {
			echo mane_elated_dynamic_css( $item_selector, $item_styles );
		}
	}
	
	add_action( 'mane_elated_action_style_dynamic', 'mane_elated_h5_styles' );
}

if ( ! function_exists( 'mane_elated_h6_styles' ) ) {
	function mane_elated_h6_styles() {
		$margin_top    = mane_elated_options()->getOptionValue( 'h6_margin_top' );
		$margin_bottom = mane_elated_options()->getOptionValue( 'h6_margin_bottom' );
		
		$item_styles = mane_elated_get_typography_styles( 'h6' );
		
		if ( $margin_top !== '' ) {
			$item_styles['margin-top'] = mane_elated_filter_px( $margin_top ) . 'px';
		}
		if ( $margin_bottom !== '' ) {
			$item_styles['margin-bottom'] = mane_elated_filter_px( $margin_bottom ) . 'px';
		}
		
		$item_selector = array(
			'h6'
		);
		
		if ( ! empty( $item_styles ) ) {
			echo mane_elated_dynamic_css( $item_selector, $item_styles );
		}
	}
	
	add_action( 'mane_elated_action_style_dynamic', 'mane_elated_h6_styles' );
}

if ( ! function_exists( 'mane_elated_text_styles' ) ) {
	function mane_elated_text_styles() {
		$item_styles = mane_elated_get_typography_styles( 'text' );
		
		$item_selector = array(
			'p'
		);
		
		if ( ! empty( $item_styles ) ) {
			echo mane_elated_dynamic_css( $item_selector, $item_styles );
		}
	}
	
	add_action( 'mane_elated_action_style_dynamic', 'mane_elated_text_styles' );
}

if ( ! function_exists( 'mane_elated_link_styles' ) ) {
	function mane_elated_link_styles() {
		$link_styles      = array();
		$link_color       = mane_elated_options()->getOptionValue( 'link_color' );
		$link_font_style  = mane_elated_options()->getOptionValue( 'link_fontstyle' );
		$link_font_weight = mane_elated_options()->getOptionValue( 'link_fontweight' );
		$link_decoration  = mane_elated_options()->getOptionValue( 'link_fontdecoration' );
		
		if ( ! empty( $link_color ) ) {
			$link_styles['color'] = $link_color;
		}
		if ( ! empty( $link_font_style ) ) {
			$link_styles['font-style'] = $link_font_style;
		}
		if ( ! empty( $link_font_weight ) ) {
			$link_styles['font-weight'] = $link_font_weight;
		}
		if ( ! empty( $link_decoration ) ) {
			$link_styles['text-decoration'] = $link_decoration;
		}
		
		$link_selector = array(
			'a',
			'p a'
		);
		
		if ( ! empty( $link_styles ) ) {
			echo mane_elated_dynamic_css( $link_selector, $link_styles );
		}
	}
	
	add_action( 'mane_elated_action_style_dynamic', 'mane_elated_link_styles' );
}

if ( ! function_exists( 'mane_elated_link_hover_styles' ) ) {
	function mane_elated_link_hover_styles() {
		$link_hover_styles     = array();
		$link_hover_color      = mane_elated_options()->getOptionValue( 'link_hovercolor' );
		$link_hover_decoration = mane_elated_options()->getOptionValue( 'link_hover_fontdecoration' );
		
		if ( ! empty( $link_hover_color ) ) {
			$link_hover_styles['color'] = $link_hover_color;
		}
		if ( ! empty( $link_hover_decoration ) ) {
			$link_hover_styles['text-decoration'] = $link_hover_decoration;
		}
		
		$link_hover_selector = array(
			'a:hover',
			'p a:hover'
		);
		
		if ( ! empty( $link_hover_styles ) ) {
			echo mane_elated_dynamic_css( $link_hover_selector, $link_hover_styles );
		}
		
		$link_heading_hover_styles = array();
		
		if ( ! empty( $link_hover_color ) ) {
			$link_heading_hover_styles['color'] = $link_hover_color;
		}
		
		$link_heading_hover_selector = array(
			'h1 a:hover',
			'h2 a:hover',
			'h3 a:hover',
			'h4 a:hover',
			'h5 a:hover',
			'h6 a:hover'
		);
		
		if ( ! empty( $link_heading_hover_styles ) ) {
			echo mane_elated_dynamic_css( $link_heading_hover_selector, $link_heading_hover_styles );
		}
	}
	
	add_action( 'mane_elated_action_style_dynamic', 'mane_elated_link_hover_styles' );
}

if ( ! function_exists( 'mane_elated_smooth_page_transition_styles' ) ) {
	function mane_elated_smooth_page_transition_styles( $style ) {
		$id            = mane_elated_get_page_id();
		$loader_style  = array();
		$current_style = '';
		
		$background_color = mane_elated_get_meta_field_intersect( 'smooth_pt_bgnd_color', $id );
		if ( ! empty( $background_color ) ) {
			$loader_style['background-color'] = $background_color;
		}
		
		$loader_selector = array(
			'.eltdf-smooth-transition-loader'
		);
		
		if ( ! empty( $loader_style ) ) {
			$current_style .= mane_elated_dynamic_css( $loader_selector, $loader_style );
		}
		
		$spinner_style = array();
		$spinner_color = mane_elated_get_meta_field_intersect( 'smooth_pt_spinner_color', $id );
		if ( ! empty( $spinner_color ) ) {
			$spinner_style['background-color'] = $spinner_color;
		}
		
		$spinner_selectors = array(
			'.eltdf-st-loader .eltdf-rotate-circles > div',
			'.eltdf-st-loader .pulse',
			'.eltdf-st-loader .double_pulse .double-bounce1',
			'.eltdf-st-loader .double_pulse .double-bounce2',
			'.eltdf-st-loader .cube',
			'.eltdf-st-loader .rotating_cubes .cube1',
			'.eltdf-st-loader .rotating_cubes .cube2',
			'.eltdf-st-loader .stripes > div',
			'.eltdf-st-loader .wave > div',
			'.eltdf-st-loader .two_rotating_circles .dot1',
			'.eltdf-st-loader .two_rotating_circles .dot2',
			'.eltdf-st-loader .five_rotating_circles .container1 > div',
			'.eltdf-st-loader .five_rotating_circles .container2 > div',
			'.eltdf-st-loader .five_rotating_circles .container3 > div',
			'.eltdf-st-loader .atom .ball-1:before',
			'.eltdf-st-loader .atom .ball-2:before',
			'.eltdf-st-loader .atom .ball-3:before',
			'.eltdf-st-loader .atom .ball-4:before',
			'.eltdf-st-loader .clock .ball:before',
			'.eltdf-st-loader .mitosis .ball',
			'.eltdf-st-loader .lines .line1',
			'.eltdf-st-loader .lines .line2',
			'.eltdf-st-loader .lines .line3',
			'.eltdf-st-loader .lines .line4',
			'.eltdf-st-loader .fussion .ball',
			'.eltdf-st-loader .fussion .ball-1',
			'.eltdf-st-loader .fussion .ball-2',
			'.eltdf-st-loader .fussion .ball-3',
			'.eltdf-st-loader .fussion .ball-4',
			'.eltdf-st-loader .wave_circles .ball',
			'.eltdf-st-loader .pulse_circles .ball'
		);
		
		if ( ! empty( $spinner_style ) ) {
			$current_style .= mane_elated_dynamic_css( $spinner_selectors, $spinner_style );
		}
		
		$current_style = $current_style . $style;
		
		return $current_style;
	}
	
	add_filter( 'mane_elated_filter_add_page_custom_style', 'mane_elated_smooth_page_transition_styles' );
}