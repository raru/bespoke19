<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<?php
	/**
	 * mane_elated_action_header_meta hook
	 *
	 * @see mane_elated_header_meta() - hooked with 10
	 * @see mane_elated_user_scalable_meta - hooked with 10
	 * @see eltdf_core_set_open_graph_meta - hooked with 10
	 */
	do_action( 'mane_elated_action_header_meta' );
	
	wp_head(); ?>
</head>
<body <?php body_class(); ?> itemscope itemtype="http://schema.org/WebPage">
	<?php
	/**
	 * mane_elated_action_after_body_tag hook
	 *
	 * @see mane_elated_get_side_area() - hooked with 10
	 * @see mane_elated_smooth_page_transitions() - hooked with 10
	 */
	do_action( 'mane_elated_action_after_body_tag' ); ?>
	
	<div class="eltdf-wrapper eltdf-404-page">
		<div class="eltdf-wrapper-inner">
            <?php
            /**
             * mane_elated_action_after_wrapper_inner hook
             *
             * @see mane_elated_get_header() - hooked with 10
             * @see mane_elated_get_mobile_header() - hooked with 20
             * @see mane_elated_back_to_top_button() - hooked with 30
             * @see mane_elated_get_header_minimal_full_screen_menu() - hooked with 40
             * @see mane_elated_get_header_bottom_navigation() - hooked with 40
             */
            do_action( 'mane_elated_action_after_wrapper_inner' );

            do_action('mane_elated_action_before_main_content'); ?>
			
			<div class="eltdf-content" <?php mane_elated_content_elem_style_attr(); ?>>
				<div class="eltdf-content-inner">
					<div class="eltdf-page-not-found">
						<?php
						$eltdf_title_image_404 = mane_elated_options()->getOptionValue( '404_page_title_image' );
						$eltdf_title_404       = mane_elated_options()->getOptionValue( '404_title' );
						$eltdf_subtitle_404    = mane_elated_options()->getOptionValue( '404_subtitle' );
						$eltdf_text_404        = mane_elated_options()->getOptionValue( '404_text' );
						$eltdf_button_label    = mane_elated_options()->getOptionValue( '404_back_to_home' );
						$eltdf_button_style    = mane_elated_options()->getOptionValue( '404_button_style' );
						
						if ( ! empty( $eltdf_title_image_404 ) ) { ?>
							<div class="eltdf-404-title-image">
								<img src="<?php echo esc_url( $eltdf_title_image_404 ); ?>" alt="<?php esc_html_e( '404 Title Image', 'mane' ); ?>" />
							</div>
						<?php } ?>
						
						<h1 class="eltdf-404-title">
							<?php if ( ! empty( $eltdf_title_404 ) ) {
								echo esc_html( $eltdf_title_404 );
							} else {
								esc_html_e( '404', 'mane' );
							} ?>
						</h1>
						
						<h2 class="eltdf-404-subtitle">
							<?php if ( ! empty( $eltdf_subtitle_404 ) ) {
								echo esc_html( $eltdf_subtitle_404 );
							} else {
								esc_html_e( 'Page not found', 'mane' );
							} ?>
						</h2>
						
						<p class="eltdf-404-text">
							<?php if ( ! empty( $eltdf_text_404 ) ) {
								echo esc_html( $eltdf_text_404 );
							} else {
								esc_html_e( 'Oops! The page you are looking for does not exist. It might have been moved or deleted.', 'mane' );
							} ?>
						</p>
						
						<?php
							$button_params = array(
								'type'              => 'outline',
                                'skin'              => 'light',
								'link'              => esc_url( home_url( '/' ) ),
								'text'              => ! empty( $eltdf_button_label ) ? $eltdf_button_label : esc_html__( 'Back to home', 'mane' ),
                                'hover_animation'   => 'yes',
							);
						
							if ( $eltdf_button_style == 'light-style' ) {
								$button_params['custom_class'] = 'eltdf-btn-light-style';
							}
							echo mane_elated_return_button_html( $button_params );
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php wp_footer(); ?>
</body>
</html>