<?php

if ( ! function_exists( 'mane_elated_map_general_meta' ) ) {
	function mane_elated_map_general_meta() {
		
		$general_meta_box = mane_elated_add_meta_box(
			array(
				'scope' => apply_filters( 'mane_elated_filter_set_scope_for_meta_boxes', array( 'page', 'post' ), 'general_meta' ),
				'title' => esc_html__( 'General', 'mane' ),
				'name'  => 'general_meta'
			)
		);
		
		/***************** Slider Layout - begin **********************/
		
		mane_elated_add_meta_box_field(
			array(
				'name'        => 'eltdf_page_slider_meta',
				'type'        => 'text',
				'label'       => esc_html__( 'Slider Shortcode', 'mane' ),
				'description' => esc_html__( 'Paste your slider shortcode here', 'mane' ),
				'parent'      => $general_meta_box
			)
		);
		
		/***************** Slider Layout - begin **********************/
		
		/***************** Content Layout - begin **********************/
		
		mane_elated_add_meta_box_field(
			array(
				'name'          => 'eltdf_page_content_behind_header_meta',
				'type'          => 'yesno',
				'default_value' => 'no',
				'label'         => esc_html__( 'Always put content behind header', 'mane' ),
				'description'   => esc_html__( 'Enabling this option will put page content behind page header', 'mane' ),
				'parent'        => $general_meta_box
			)
		);
		
		$eltdf_content_padding_group = mane_elated_add_admin_group(
			array(
				'name'        => 'content_padding_group',
				'title'       => esc_html__( 'Content Style', 'mane' ),
				'description' => esc_html__( 'Define styles for Content area', 'mane' ),
				'parent'      => $general_meta_box
			)
		);
		
			$eltdf_content_padding_row = mane_elated_add_admin_row(
				array(
					'name'   => 'eltdf_content_padding_row',
					'next'   => true,
					'parent' => $eltdf_content_padding_group
				)
			);
		
				mane_elated_add_meta_box_field(
					array(
						'name'   => 'eltdf_page_content_top_padding',
						'type'   => 'textsimple',
						'label'  => esc_html__( 'Content Top Padding', 'mane' ),
						'parent' => $eltdf_content_padding_row,
						'args'   => array(
							'suffix' => 'px'
						)
					)
				);
				
				mane_elated_add_meta_box_field(
					array(
						'name'    => 'eltdf_page_content_top_padding_mobile',
						'type'    => 'selectsimple',
						'label'   => esc_html__( 'Set this top padding for mobile header', 'mane' ),
						'parent'  => $eltdf_content_padding_row,
						'options' => mane_elated_get_yes_no_select_array( false )
					)
				);
		
		mane_elated_add_meta_box_field(
			array(
				'name'        => 'eltdf_page_background_color_meta',
				'type'        => 'color',
				'label'       => esc_html__( 'Page Background Color', 'mane' ),
				'description' => esc_html__( 'Choose background color for page content', 'mane' ),
				'parent'      => $general_meta_box
			)
		);
		
		/***************** Content Layout - end **********************/
		
		/***************** Boxed Layout - begin **********************/
		
		mane_elated_add_meta_box_field(
			array(
				'name'    => 'eltdf_boxed_meta',
				'type'    => 'select',
				'label'   => esc_html__( 'Boxed Layout', 'mane' ),
				'parent'  => $general_meta_box,
				'options' => mane_elated_get_yes_no_select_array(),
				'args'    => array(
					'dependence' => true,
					'hide'       => array(
						''    => '#eltdf_boxed_container_meta',
						'no'  => '#eltdf_boxed_container_meta',
						'yes' => ''
					),
					'show'       => array(
						''    => '',
						'no'  => '',
						'yes' => '#eltdf_boxed_container_meta'
					)
				)
			)
		);
		
			$boxed_container_meta = mane_elated_add_admin_container(
				array(
					'parent'          => $general_meta_box,
					'name'            => 'boxed_container_meta',
					'hidden_property' => 'eltdf_boxed_meta',
					'hidden_values'   => array(
						'',
						'no'
					)
				)
			);
		
				mane_elated_add_meta_box_field(
					array(
						'name'        => 'eltdf_page_background_color_in_box_meta',
						'type'        => 'color',
						'label'       => esc_html__( 'Page Background Color', 'mane' ),
						'description' => esc_html__( 'Choose the page background color outside box', 'mane' ),
						'parent'      => $boxed_container_meta
					)
				);
				
				mane_elated_add_meta_box_field(
					array(
						'name'        => 'eltdf_boxed_background_image_meta',
						'type'        => 'image',
						'label'       => esc_html__( 'Background Image', 'mane' ),
						'description' => esc_html__( 'Choose an image to be displayed in background', 'mane' ),
						'parent'      => $boxed_container_meta
					)
				);
				
				mane_elated_add_meta_box_field(
					array(
						'name'        => 'eltdf_boxed_pattern_background_image_meta',
						'type'        => 'image',
						'label'       => esc_html__( 'Background Pattern', 'mane' ),
						'description' => esc_html__( 'Choose an image to be used as background pattern', 'mane' ),
						'parent'      => $boxed_container_meta
					)
				);
				
				mane_elated_add_meta_box_field(
					array(
						'name'          => 'eltdf_boxed_background_image_attachment_meta',
						'type'          => 'select',
						'default_value' => 'fixed',
						'label'         => esc_html__( 'Background Image Attachment', 'mane' ),
						'description'   => esc_html__( 'Choose background image attachment', 'mane' ),
						'parent'        => $boxed_container_meta,
						'options'       => array(
							''       => esc_html__( 'Default', 'mane' ),
							'fixed'  => esc_html__( 'Fixed', 'mane' ),
							'scroll' => esc_html__( 'Scroll', 'mane' )
						)
					)
				);
		
		/***************** Boxed Layout - end **********************/
		
		/***************** Passepartout Layout - begin **********************/
		
		mane_elated_add_meta_box_field(
			array(
				'name'          => 'eltdf_paspartu_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Passepartout', 'mane' ),
				'description'   => esc_html__( 'Enabling this option will display passepartout around site content', 'mane' ),
				'parent'        => $general_meta_box,
				'options'       => mane_elated_get_yes_no_select_array(),
				'args'    => array(
					'dependence'    => true,
					'hide'          => array(
						''    => '#eltdf_eltdf_paspartu_container_meta',
						'no'  => '#eltdf_eltdf_paspartu_container_meta',
						'yes' => ''
					),
					'show'          => array(
						''    => '',
						'no'  => '',
						'yes' => '#eltdf_eltdf_paspartu_container_meta'
					)
				)
			)
		);
		
			$paspartu_container_meta = mane_elated_add_admin_container(
				array(
					'parent'          => $general_meta_box,
					'name'            => 'eltdf_paspartu_container_meta',
					'hidden_property' => 'eltdf_paspartu_meta',
					'hidden_values'   => array(
						'',
						'no'
					)
				)
			);
		
				mane_elated_add_meta_box_field(
					array(
						'name'        => 'eltdf_paspartu_color_meta',
						'type'        => 'color',
						'label'       => esc_html__( 'Passepartout Color', 'mane' ),
						'description' => esc_html__( 'Choose passepartout color, default value is #ffffff', 'mane' ),
						'parent'      => $paspartu_container_meta
					)
				);
				
				mane_elated_add_meta_box_field(
					array(
						'name'        => 'eltdf_paspartu_width_meta',
						'type'        => 'text',
						'label'       => esc_html__( 'Passepartout Size', 'mane' ),
						'description' => esc_html__( 'Enter size amount for passepartout', 'mane' ),
						'parent'      => $paspartu_container_meta,
						'args'        => array(
							'col_width' => 2,
							'suffix'    => 'px or %'
						)
					)
				);
		
				mane_elated_add_meta_box_field(
					array(
						'name'        => 'eltdf_paspartu_responsive_width_meta',
						'type'        => 'text',
						'label'       => esc_html__( 'Responsive Passepartout Size', 'mane' ),
						'description' => esc_html__( 'Enter size amount for passepartout for smaller screens (tablets and mobiles view)', 'mane' ),
						'parent'      => $paspartu_container_meta,
						'args'        => array(
							'col_width' => 2,
							'suffix'    => 'px or %'
						)
					)
				);
				
				mane_elated_add_meta_box_field(
					array(
						'parent'        => $paspartu_container_meta,
						'type'          => 'select',
						'default_value' => '',
						'name'          => 'eltdf_disable_top_paspartu_meta',
						'label'         => esc_html__( 'Disable Top Passepartout', 'mane' ),
						'options'       => mane_elated_get_yes_no_select_array(),
					)
				);
		
		/***************** Passepartout Layout - end **********************/
		
		/***************** Content Width Layout - begin **********************/
		
		mane_elated_add_meta_box_field(
			array(
				'name'          => 'eltdf_initial_content_width_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Initial Width of Content', 'mane' ),
				'description'   => esc_html__( 'Choose the initial width of content which is in grid (Applies to pages set to "Default Template" and rows set to "In Grid")', 'mane' ),
				'parent'        => $general_meta_box,
				'options'       => array(
					''                => esc_html__( 'Default', 'mane' ),
					'eltdf-grid-1300' => esc_html__( '1300px', 'mane' ),
					'eltdf-grid-1400' => esc_html__( '1400px', 'mane' ),
					'eltdf-grid-1200' => esc_html__( '1200px', 'mane' ),
					'eltdf-grid-1100' => esc_html__( '1100px', 'mane' ),
					'eltdf-grid-1000' => esc_html__( '1000px', 'mane' ),
					'eltdf-grid-800'  => esc_html__( '800px', 'mane' )
				)
			)
		);
		
		/***************** Content Width Layout - end **********************/
		
		/***************** Smooth Page Transitions Layout - begin **********************/
		
		mane_elated_add_meta_box_field(
			array(
				'name'          => 'eltdf_smooth_page_transitions_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Smooth Page Transitions', 'mane' ),
				'description'   => esc_html__( 'Enabling this option will perform a smooth transition between pages when clicking on links', 'mane' ),
				'parent'        => $general_meta_box,
				'options'       => mane_elated_get_yes_no_select_array(),
				'args'          => array(
					'dependence' => true,
					'hide'       => array(
						''    => '#eltdf_page_transitions_container_meta',
						'no'  => '#eltdf_page_transitions_container_meta',
						'yes' => ''
					),
					'show'       => array(
						''    => '',
						'no'  => '',
						'yes' => '#eltdf_page_transitions_container_meta'
					)
				)
			)
		);
		
			$page_transitions_container_meta = mane_elated_add_admin_container(
				array(
					'parent'          => $general_meta_box,
					'name'            => 'page_transitions_container_meta',
					'hidden_property' => 'eltdf_smooth_page_transitions_meta',
					'hidden_values'   => array(
						'',
						'no'
					)
				)
			);
		
				mane_elated_add_meta_box_field(
					array(
						'name'        => 'eltdf_page_transition_preloader_meta',
						'type'        => 'select',
						'label'       => esc_html__( 'Enable Preloading Animation', 'mane' ),
						'description' => esc_html__( 'Enabling this option will display an animated preloader while the page content is loading', 'mane' ),
						'parent'      => $page_transitions_container_meta,
						'options'     => mane_elated_get_yes_no_select_array(),
						'args'        => array(
							'dependence' => true,
							'hide'       => array(
								''    => '#eltdf_page_transition_preloader_container_meta',
								'no'  => '#eltdf_page_transition_preloader_container_meta',
								'yes' => ''
							),
							'show'       => array(
								''    => '',
								'no'  => '',
								'yes' => '#eltdf_page_transition_preloader_container_meta'
							)
						)
					)
				);
				
				$page_transition_preloader_container_meta = mane_elated_add_admin_container(
					array(
						'parent'          => $page_transitions_container_meta,
						'name'            => 'page_transition_preloader_container_meta',
						'hidden_property' => 'eltdf_page_transition_preloader_meta',
						'hidden_values'   => array(
							'',
							'no'
						)
					)
				);
				
					mane_elated_add_meta_box_field(
						array(
							'name'   => 'eltdf_smooth_pt_bgnd_color_meta',
							'type'   => 'color',
							'label'  => esc_html__( 'Page Loader Background Color', 'mane' ),
							'parent' => $page_transition_preloader_container_meta
						)
					);
					
					$group_pt_spinner_animation_meta = mane_elated_add_admin_group(
						array(
							'name'        => 'group_pt_spinner_animation_meta',
							'title'       => esc_html__( 'Loader Style', 'mane' ),
							'description' => esc_html__( 'Define styles for loader spinner animation', 'mane' ),
							'parent'      => $page_transition_preloader_container_meta
						)
					);
					
					$row_pt_spinner_animation_meta = mane_elated_add_admin_row(
						array(
							'name'   => 'row_pt_spinner_animation_meta',
							'parent' => $group_pt_spinner_animation_meta
						)
					);
					
					mane_elated_add_meta_box_field(
						array(
							'type'    => 'selectsimple',
							'name'    => 'eltdf_smooth_pt_spinner_type_meta',
							'label'   => esc_html__( 'Spinner Type', 'mane' ),
							'parent'  => $row_pt_spinner_animation_meta,
							'options' => array(
								''                      => esc_html__( 'Default', 'mane' ),
								'rotate_circles'        => esc_html__( 'Rotate Circles', 'mane' ),
								'pulse'                 => esc_html__( 'Pulse', 'mane' ),
								'double_pulse'          => esc_html__( 'Double Pulse', 'mane' ),
								'cube'                  => esc_html__( 'Cube', 'mane' ),
								'rotating_cubes'        => esc_html__( 'Rotating Cubes', 'mane' ),
								'stripes'               => esc_html__( 'Stripes', 'mane' ),
								'wave'                  => esc_html__( 'Wave', 'mane' ),
								'two_rotating_circles'  => esc_html__( '2 Rotating Circles', 'mane' ),
								'five_rotating_circles' => esc_html__( '5 Rotating Circles', 'mane' ),
								'atom'                  => esc_html__( 'Atom', 'mane' ),
								'clock'                 => esc_html__( 'Clock', 'mane' ),
								'mitosis'               => esc_html__( 'Mitosis', 'mane' ),
								'lines'                 => esc_html__( 'Lines', 'mane' ),
								'fussion'               => esc_html__( 'Fussion', 'mane' ),
								'wave_circles'          => esc_html__( 'Wave Circles', 'mane' ),
								'pulse_circles'         => esc_html__( 'Pulse Circles', 'mane' )
							)
						)
					);
					
					mane_elated_add_meta_box_field(
						array(
							'type'   => 'colorsimple',
							'name'   => 'eltdf_smooth_pt_spinner_color_meta',
							'label'  => esc_html__( 'Spinner Color', 'mane' ),
							'parent' => $row_pt_spinner_animation_meta
						)
					);
					
					mane_elated_add_meta_box_field(
						array(
							'name'        => 'eltdf_page_transition_fadeout_meta',
							'type'        => 'select',
							'label'       => esc_html__( 'Enable Fade Out Animation', 'mane' ),
							'description' => esc_html__( 'Enabling this option will turn on fade out animation when leaving page', 'mane' ),
							'options'     => mane_elated_get_yes_no_select_array(),
							'parent'      => $page_transitions_container_meta
						
						)
					);
		
		/***************** Smooth Page Transitions Layout - end **********************/
		
		/***************** Comments Layout - begin **********************/
		
		mane_elated_add_meta_box_field(
			array(
				'name'        => 'eltdf_page_comments_meta',
				'type'        => 'select',
				'label'       => esc_html__( 'Show Comments', 'mane' ),
				'description' => esc_html__( 'Enabling this option will show comments on your page', 'mane' ),
				'parent'      => $general_meta_box,
				'options'     => mane_elated_get_yes_no_select_array()
			)
		);
		
		/***************** Comments Layout - end **********************/
	}
	
	add_action( 'mane_elated_action_meta_boxes_map', 'mane_elated_map_general_meta', 10 );
}