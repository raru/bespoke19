<?php

if ( ! function_exists( 'mane_elated_register_custom_font_widget' ) ) {
	/**
	 * Function that register custom font widget
	 */
	function mane_elated_register_custom_font_widget( $widgets ) {
		$widgets[] = 'ManeElatedPhpClassCustomFontWidget';
		
		return $widgets;
	}
	
	add_filter( 'mane_elated_filter_register_widgets', 'mane_elated_register_custom_font_widget' );
}