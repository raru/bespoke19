<?php

if ( ! function_exists( 'mane_elated_register_sidearea_opener_widget' ) ) {
	/**
	 * Function that register sidearea opener widget
	 */
	function mane_elated_register_sidearea_opener_widget( $widgets ) {
		$widgets[] = 'ManeElatedPhpClassSideAreaOpener';
		
		return $widgets;
	}
	
	add_filter( 'mane_elated_filter_register_widgets', 'mane_elated_register_sidearea_opener_widget' );
}