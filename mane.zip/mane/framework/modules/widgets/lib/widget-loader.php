<?php

if ( ! function_exists( 'mane_elated_register_widgets' ) ) {
	function mane_elated_register_widgets() {
		$widgets = apply_filters( 'mane_elated_filter_register_widgets', $widgets = array() );
		
		foreach ( $widgets as $widget ) {
			register_widget( $widget );
		}
	}
	
	add_action( 'widgets_init', 'mane_elated_register_widgets' );
}