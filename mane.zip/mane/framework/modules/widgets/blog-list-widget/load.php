<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/blog-list-widget/functions.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/blog-list-widget/blog-list.php';