<?php

if ( ! function_exists( 'mane_elated_register_blog_list_widget' ) ) {
	/**
	 * Function that register blog list widget
	 */
	function mane_elated_register_blog_list_widget( $widgets ) {
		$widgets[] = 'ManeElatedPhpClassBlogListWidget';
		
		return $widgets;
	}
	
	add_filter( 'mane_elated_filter_register_widgets', 'mane_elated_register_blog_list_widget' );
}