<?php

if ( ! function_exists( 'mane_elated_register_icon_widget' ) ) {
	/**
	 * Function that register icon widget
	 */
	function mane_elated_register_icon_widget( $widgets ) {
		$widgets[] = 'ManeElatedPhpClassIconWidget';
		
		return $widgets;
	}
	
	add_filter( 'mane_elated_filter_register_widgets', 'mane_elated_register_icon_widget' );
}