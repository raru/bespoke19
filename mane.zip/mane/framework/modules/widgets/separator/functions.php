<?php

if ( ! function_exists( 'mane_elated_register_separator_widget' ) ) {
	/**
	 * Function that register separator widget
	 */
	function mane_elated_register_separator_widget( $widgets ) {
		$widgets[] = 'ManeElatedPhpClassSeparatorWidget';
		
		return $widgets;
	}
	
	add_filter( 'mane_elated_filter_register_widgets', 'mane_elated_register_separator_widget' );
}