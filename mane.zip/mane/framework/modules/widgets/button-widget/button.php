<?php

class ManeElatedPhpClassButtonWidget extends ManeElatedPhpClassWidget {
	public function __construct() {
		parent::__construct(
			'eltdf_button_widget',
			esc_html__( 'Elated Button Widget', 'mane' ),
			array( 'description' => esc_html__( 'Add button element to widget areas', 'mane' ) )
		);
		
		$this->setParams();
	}
	
	protected function setParams() {
		$this->params = array(
			array(
				'type'    => 'dropdown',
				'name'    => 'type',
				'title'   => esc_html__( 'Type', 'mane' ),
				'options' => array(
					'solid'   => esc_html__( 'Solid', 'mane' ),
					'outline' => esc_html__( 'Outline', 'mane' ),
					'simple'  => esc_html__( 'Simple', 'mane' )
				)
			),
			array(
				'type'        => 'dropdown',
				'name'        => 'size',
				'title'       => esc_html__( 'Size', 'mane' ),
				'options'     => array(
					'small'  => esc_html__( 'Small', 'mane' ),
					'medium' => esc_html__( 'Medium', 'mane' ),
					'large'  => esc_html__( 'Large', 'mane' ),
					'huge'   => esc_html__( 'Huge', 'mane' )
				),
				'description' => esc_html__( 'This option is only available for solid and outline button type', 'mane' )
			),
			array(
				'type'    => 'textfield',
				'name'    => 'text',
				'title'   => esc_html__( 'Text', 'mane' ),
				'default' => esc_html__( 'Button Text', 'mane' )
			),
			array(
				'type'  => 'textfield',
				'name'  => 'link',
				'title' => esc_html__( 'Link', 'mane' )
			),
			array(
				'type'    => 'dropdown',
				'name'    => 'target',
				'title'   => esc_html__( 'Link Target', 'mane' ),
				'options' => mane_elated_get_link_target_array()
			),
			array(
				'type'  => 'colorpicker',
				'name'  => 'color',
				'title' => esc_html__( 'Color', 'mane' )
			),
			array(
				'type'  => 'colorpicker',
				'name'  => 'hover_color',
				'title' => esc_html__( 'Hover Color', 'mane' )
			),
			array(
				'type'        => 'colorpicker',
				'name'        => 'background_color',
				'title'       => esc_html__( 'Background Color', 'mane' ),
				'description' => esc_html__( 'This option is only available for solid button type', 'mane' )
			),
			array(
				'type'        => 'colorpicker',
				'name'        => 'hover_background_color',
				'title'       => esc_html__( 'Hover Background Color', 'mane' ),
				'description' => esc_html__( 'This option is only available for solid button type', 'mane' )
			),
			array(
				'type'        => 'colorpicker',
				'name'        => 'border_color',
				'title'       => esc_html__( 'Border Color', 'mane' ),
				'description' => esc_html__( 'This option is only available for solid and outline button type', 'mane' )
			),
			array(
				'type'        => 'colorpicker',
				'name'        => 'hover_border_color',
				'title'       => esc_html__( 'Hover Border Color', 'mane' ),
				'description' => esc_html__( 'This option is only available for solid and outline button type', 'mane' )
			),
			array(
				'type'        => 'textfield',
				'name'        => 'margin',
				'title'       => esc_html__( 'Margin', 'mane' ),
				'description' => esc_html__( 'Insert margin in format: top right bottom left (e.g. 10px 5px 10px 5px)', 'mane' )
			)
		);
	}
	
	public function widget( $args, $instance ) {
		$params = '';
		
		if ( ! is_array( $instance ) ) {
			$instance = array();
		}
		
		// Filter out all empty params
		$instance = array_filter( $instance, function ( $array_value ) {
			return trim( $array_value ) != '';
		} );
		
		// Default values
		if ( ! isset( $instance['text'] ) ) {
			$instance['text'] = 'Button Text';
		}
		
		// Generate shortcode params
		foreach ( $instance as $key => $value ) {
			$params .= " $key='$value' ";
		}
		
		echo '<div class="widget eltdf-button-widget">';
			echo do_shortcode( "[eltdf_button $params]" ); // XSS OK
		echo '</div>';
	}
}