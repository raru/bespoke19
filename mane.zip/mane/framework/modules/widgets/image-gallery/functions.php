<?php

if ( ! function_exists( 'mane_elated_register_image_gallery_widget' ) ) {
	/**
	 * Function that register image gallery widget
	 */
	function mane_elated_register_image_gallery_widget( $widgets ) {
		$widgets[] = 'ManeElatedPhpClassImageGalleryWidget';
		
		return $widgets;
	}
	
	add_filter( 'mane_elated_filter_register_widgets', 'mane_elated_register_image_gallery_widget' );
}