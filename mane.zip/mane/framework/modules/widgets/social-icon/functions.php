<?php

if ( ! function_exists( 'mane_elated_register_social_icon_widget' ) ) {
	/**
	 * Function that register social icon widget
	 */
	function mane_elated_register_social_icon_widget( $widgets ) {
		$widgets[] = 'ManeElatedPhpClassSocialIconWidget';
		
		return $widgets;
	}
	
	add_filter( 'mane_elated_filter_register_widgets', 'mane_elated_register_social_icon_widget' );
}