<?php

if ( ! function_exists( 'mane_elated_register_search_opener_widget' ) ) {
	/**
	 * Function that register search opener widget
	 */
	function mane_elated_register_search_opener_widget( $widgets ) {
		$widgets[] = 'ManeElatedPhpClassSearchOpener';
		
		return $widgets;
	}
	
	add_filter( 'mane_elated_filter_register_widgets', 'mane_elated_register_search_opener_widget' );
}