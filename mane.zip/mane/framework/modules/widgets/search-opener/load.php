<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/search-opener/functions.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/search-opener/search-opener.php';
