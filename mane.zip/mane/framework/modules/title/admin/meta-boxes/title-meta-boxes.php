<?php

if ( ! function_exists( 'mane_elated_get_title_types_meta_boxes' ) ) {
	function mane_elated_get_title_types_meta_boxes() {
		$title_type_options = apply_filters( 'mane_elated_filter_title_type_meta_boxes', $title_type_options = array( '' => esc_html__( 'Default', 'mane' ) ) );
		
		return $title_type_options;
	}
}

foreach ( glob( ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/title/types/*/admin/meta-boxes/*.php' ) as $meta_box_load ) {
	include_once $meta_box_load;
}

if ( ! function_exists( 'mane_elated_map_title_meta' ) ) {
	function mane_elated_map_title_meta() {
		$title_type_meta_boxes = mane_elated_get_title_types_meta_boxes();
		
		$title_meta_box = mane_elated_add_meta_box(
			array(
				'scope' => apply_filters( 'mane_elated_filter_set_scope_for_meta_boxes', array( 'page', 'post' ), 'title_meta' ),
				'title' => esc_html__( 'Title', 'mane' ),
				'name'  => 'title_meta'
			)
		);
		
		mane_elated_add_meta_box_field(
			array(
				'name'          => 'eltdf_show_title_area_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Show Title Area', 'mane' ),
				'description'   => esc_html__( 'Disabling this option will turn off page title area', 'mane' ),
				'parent'        => $title_meta_box,
				'options'       => mane_elated_get_yes_no_select_array(),
				'args'          => array(
					'dependence' => true,
					'hide'       => array(
						''    => '',
						'no'  => '#eltdf_eltdf_show_title_area_meta_container',
						'yes' => ''
					),
					'show'       => array(
						''    => '#eltdf_eltdf_show_title_area_meta_container',
						'no'  => '',
						'yes' => '#eltdf_eltdf_show_title_area_meta_container'
					)
				)
			)
		);
		
			$show_title_area_meta_container = mane_elated_add_admin_container(
				array(
					'parent'          => $title_meta_box,
					'name'            => 'eltdf_show_title_area_meta_container',
					'hidden_property' => 'eltdf_show_title_area_meta',
					'hidden_value'    => 'no'
				)
			);
		
				mane_elated_add_meta_box_field(
					array(
						'name'          => 'eltdf_title_area_type_meta',
						'type'          => 'select',
						'default_value' => '',
						'label'         => esc_html__( 'Title Area Type', 'mane' ),
						'description'   => esc_html__( 'Choose title type', 'mane' ),
						'parent'        => $show_title_area_meta_container,
						'options'       => $title_type_meta_boxes
					)
				);
		
				mane_elated_add_meta_box_field(
					array(
						'name'          => 'eltdf_title_area_in_grid_meta',
						'type'          => 'select',
						'default_value' => '',
						'label'         => esc_html__( 'Title Area In Grid', 'mane' ),
						'description'   => esc_html__( 'Set title area content to be in grid', 'mane' ),
						'options'       => mane_elated_get_yes_no_select_array(),
						'parent'        => $show_title_area_meta_container
					)
				);
		
				mane_elated_add_meta_box_field(
					array(
						'name'        => 'eltdf_title_area_height_meta',
						'type'        => 'text',
						'label'       => esc_html__( 'Height', 'mane' ),
						'description' => esc_html__( 'Set a height for Title Area', 'mane' ),
						'parent'      => $show_title_area_meta_container,
						'args'        => array(
							'col_width' => 2,
							'suffix'    => 'px'
						)
					)
				);
				
				mane_elated_add_meta_box_field(
					array(
						'name'        => 'eltdf_title_area_background_color_meta',
						'type'        => 'color',
						'label'       => esc_html__( 'Background Color', 'mane' ),
						'description' => esc_html__( 'Choose a background color for title area', 'mane' ),
						'parent'      => $show_title_area_meta_container
					)
				);
		
				mane_elated_add_meta_box_field(
					array(
						'name'        => 'eltdf_title_area_background_image_meta',
						'type'        => 'image',
						'label'       => esc_html__( 'Background Image', 'mane' ),
						'description' => esc_html__( 'Choose an Image for title area', 'mane' ),
						'parent'      => $show_title_area_meta_container
					)
				);
		
				mane_elated_add_meta_box_field(
					array(
						'name'          => 'eltdf_title_area_background_image_behavior_meta',
						'type'          => 'select',
						'default_value' => '',
						'label'         => esc_html__( 'Background Image Behavior', 'mane' ),
						'description'   => esc_html__( 'Choose title area background image behavior', 'mane' ),
						'parent'        => $show_title_area_meta_container,
						'options'       => array(
							''                    => esc_html__( 'Default', 'mane' ),
							'hide'                => esc_html__( 'Hide Image', 'mane' ),
							'responsive'          => esc_html__( 'Enable Responsive Image', 'mane' ),
							'responsive-disabled' => esc_html__( 'Disable Responsive Image', 'mane' ),
							'parallax'            => esc_html__( 'Enable Parallax Image', 'mane' ),
							'parallax-zoom-out'   => esc_html__( 'Enable Parallax With Zoom Out Image', 'mane' ),
							'parallax-disabled'   => esc_html__( 'Disable Parallax Image', 'mane' )
						)
					)
				);
				
				mane_elated_add_meta_box_field(
					array(
						'name'          => 'eltdf_title_area_vertical_alignment_meta',
						'type'          => 'select',
						'default_value' => '',
						'label'         => esc_html__( 'Vertical Alignment', 'mane' ),
						'description'   => esc_html__( 'Specify title area content vertical alignment', 'mane' ),
						'parent'        => $show_title_area_meta_container,
						'options'       => array(
							''              => esc_html__( 'Default', 'mane' ),
							'header_bottom' => esc_html__( 'From Bottom of Header', 'mane' ),
							'window_top'    => esc_html__( 'From Window Top', 'mane' )
						)
					)
				);

		mane_elated_add_meta_box_field(
			array(
				'name'          => 'eltdf_title_area_title_custom_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Use Our Predefined Title Style', 'mane' ),
				'options'       => mane_elated_get_yes_no_select_array( false ),
				'parent'        => $show_title_area_meta_container
			)
		);
				
				mane_elated_add_meta_box_field(
					array(
						'name'          => 'eltdf_title_area_title_tag_meta',
						'type'          => 'select',
						'default_value' => '',
						'label'         => esc_html__( 'Title Tag', 'mane' ),
						'options'       => mane_elated_get_title_tag( true ),
						'parent'        => $show_title_area_meta_container
					)
				);
				
				mane_elated_add_meta_box_field(
					array(
						'name'        => 'eltdf_title_text_color_meta',
						'type'        => 'color',
						'label'       => esc_html__( 'Title Color', 'mane' ),
						'description' => esc_html__( 'Choose a color for title text', 'mane' ),
						'parent'      => $show_title_area_meta_container
					)
				);
				
				mane_elated_add_meta_box_field(
					array(
						'name'          => 'eltdf_title_area_subtitle_meta',
						'type'          => 'text',
						'default_value' => '',
						'label'         => esc_html__( 'Subtitle Text', 'mane' ),
						'description'   => esc_html__( 'Enter your subtitle text', 'mane' ),
						'parent'        => $show_title_area_meta_container,
						'args'          => array(
							'col_width' => 6
						)
					)
				);
		
				mane_elated_add_meta_box_field(
					array(
						'name'          => 'eltdf_title_area_subtitle_tag_meta',
						'type'          => 'select',
						'default_value' => '',
						'label'         => esc_html__( 'Subtitle Tag', 'mane' ),
						'options'       => mane_elated_get_title_tag( true, array( 'p' => 'p' ) ),
						'parent'        => $show_title_area_meta_container
					)
				);
				
				mane_elated_add_meta_box_field(
					array(
						'name'        => 'eltdf_subtitle_color_meta',
						'type'        => 'color',
						'label'       => esc_html__( 'Subtitle Color', 'mane' ),
						'description' => esc_html__( 'Choose a color for subtitle text', 'mane' ),
						'parent'      => $show_title_area_meta_container
					)
				);
		
		/***************** Additional Title Area Layout - start *****************/
		
		do_action( 'mane_elated_action_additional_title_area_meta_boxes', $show_title_area_meta_container );
		
		/***************** Additional Title Area Layout - end *****************/
		
	}
	
	add_action( 'mane_elated_action_meta_boxes_map', 'mane_elated_map_title_meta', 60 );
}