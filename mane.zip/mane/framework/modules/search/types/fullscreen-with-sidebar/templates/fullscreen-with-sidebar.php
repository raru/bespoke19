<div class="eltdf-fullscreen-with-sidebar-search-holder">
	<a class="eltdf-fullscreen-search-close" href="javascript:void(0)">
		<?php echo mane_elated_icon_collections()->renderIcon( 'fa fa-times', 'font_awesome' ); ?>
	</a>
	<div class="eltdf-fullscreen-search-table">
		<div class="eltdf-fullscreen-search-cell">
			<div class="eltdf-fullscreen-search-inner  <?php echo esc_html($search_in_grid); ?>">
				<form action="<?php echo esc_url( home_url( '/' ) ); ?>" class="eltdf-fullscreen-search-form" method="get">
					<div class="eltdf-form-holder">
						<div class="eltdf-form-holder-inner">
							<div class="eltdf-field-holder">
								<input type="text" placeholder="<?php esc_html_e( 'Search...', 'mane' ); ?>" name="s" class="eltdf-search-field" autocomplete="off"/>
							</div>
							<button type="submit" class="eltdf-search-submit"><?php echo mane_elated_icon_collections()->renderIcon( 'fa-search', 'font_awesome' ); ?></button>
						</div>
					</div>
				</form>
                <div class="eltdf-fullscreen-sidebar">
                    <?php mane_elated_get_fullscreen_sidebar(); ?>
                </div>
			</div>
		</div>
	</div>
</div>