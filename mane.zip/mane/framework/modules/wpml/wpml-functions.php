<?php

if ( ! function_exists( 'mane_elated_disable_wpml_css' ) ) {
	function mane_elated_disable_wpml_css() {
		define( 'ICL_DONT_LOAD_LANGUAGE_SELECTOR_CSS', true );
	}
	
	add_action( 'after_setup_theme', 'mane_elated_disable_wpml_css' );
}