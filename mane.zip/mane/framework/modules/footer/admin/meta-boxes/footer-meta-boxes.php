<?php

if ( ! function_exists( 'mane_elated_map_footer_meta' ) ) {
	function mane_elated_map_footer_meta() {
		
		$footer_meta_box = mane_elated_add_meta_box(
			array(
				'scope' => apply_filters( 'mane_elated_filter_set_scope_for_meta_boxes', array( 'page', 'post' ), 'footer_meta' ),
				'title' => esc_html__( 'Footer', 'mane' ),
				'name'  => 'footer_meta'
			)
		);
		
		mane_elated_add_meta_box_field(
			array(
				'name'          => 'eltdf_disable_footer_meta',
				'type'          => 'select',
				'default_value' => 'no',
				'label'         => esc_html__( 'Disable Footer for this Page', 'mane' ),
				'description'   => esc_html__( 'Enabling this option will hide footer on this page', 'mane' ),
				'options'       => mane_elated_get_yes_no_select_array( false ),
				'parent'        => $footer_meta_box,
				'args'          => array(
					'dependence' => true,
					'hide'       => array(
						'no'  => '',
						'yes' => '#eltdf_eltdf_show_footer_meta_container'
					),
					'show'       => array(
						'no'  => '#eltdf_eltdf_show_footer_meta_container',
						'yes' => ''
					)
				)
			)
		);
		
		$show_footer_meta_container = mane_elated_add_admin_container(
			array(
				'name'            => 'eltdf_show_footer_meta_container',
				'hidden_property' => 'eltdf_disable_footer_meta',
				'hidden_value'    => 'yes',
				'parent'          => $footer_meta_box
			)
		);
		
        mane_elated_add_meta_box_field(
            array(
                'name'          => 'eltdf_show_footer_top_meta',
                'type'          => 'select',
                'default_value' => '',
                'label'         => esc_html__( 'Show Footer Top', 'mane' ),
                'description'   => esc_html__( 'Enabling this option will show Footer Top area', 'mane' ),
                'options'       => mane_elated_get_yes_no_select_array(),
                'parent'        => $show_footer_meta_container
            )
        );

        mane_elated_add_meta_box_field(
            array(
                'name'          => 'eltdf_footer_top_predefined_styles_meta',
                'type'          => 'select',
                'default_value' => '',
                'label'         => esc_html__( 'Use our predefined styles when Footer top is in grid', 'mane' ),
                'description'   => esc_html__( 'Use this option to enable predefined styles for Footer Top area when in grid', 'mane' ),
                'options'       => mane_elated_get_yes_no_select_array(),
                'parent'        => $show_footer_meta_container
            )
        );

        mane_elated_add_meta_box_field(
            array(
                'name'          => 'eltdf_show_footer_bottom_meta',
                'type'          => 'select',
                'default_value' => '',
                'label'         => esc_html__( 'Show Footer Bottom', 'mane' ),
                'description'   => esc_html__( 'Enabling this option will show Footer Bottom area', 'mane' ),
                'options'       => mane_elated_get_yes_no_select_array(),
                'parent'        => $show_footer_meta_container
            )
        );

        mane_elated_add_meta_box_field(
            array(
                'name'          => 'eltdf_uncovering_footer_meta',
                'type'          => 'select',
                'default_value' => '',
                'label'         => esc_html__( 'Uncovering Footer', 'mane' ),
                'description'   => esc_html__( 'Enabling this option will make Footer gradually appear on scroll', 'mane' ),
                'options'       => mane_elated_get_yes_no_select_array(),
                'parent'        => $footer_meta_box,
            )
        );
	}
	
	add_action( 'mane_elated_action_meta_boxes_map', 'mane_elated_map_footer_meta', 70 );
}