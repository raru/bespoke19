<?php

if ( ! function_exists( 'mane_elated_footer_top_general_styles' ) ) {
	/**
	 * Generates general custom styles for footer top area
	 */
	function mane_elated_footer_top_general_styles() {
		$item_styles      = array();
		$background_color = mane_elated_options()->getOptionValue( 'footer_top_background_color' );
		
		if ( ! empty( $background_color ) ) {
			$item_styles['background-color'] = $background_color;
		}
		
		echo mane_elated_dynamic_css( '.eltdf-page-footer .eltdf-footer-top-holder', $item_styles );
	}
	
	add_action( 'mane_elated_action_style_dynamic', 'mane_elated_footer_top_general_styles' );
}

if ( ! function_exists( 'mane_elated_footer_bottom_general_styles' ) ) {
	/**
	 * Generates general custom styles for footer bottom area
	 */
	function mane_elated_footer_bottom_general_styles() {
		$item_styles        = array();
		$pseudo_item_styles = array();
		$background_color   = mane_elated_options()->getOptionValue( 'footer_bottom_background_color' );
		$background_image   = mane_elated_options()->getOptionValue( 'footer_bottom_background_image' );
		
		if ( ! empty( $background_color ) && empty( $background_image ) ) {
			$item_styles['background-color'] = $background_color;
		} elseif ( ! empty( $background_image ) ) {
			$pseudo_item_styles['background-color'] = 'rgba(31, 31, 31, .5)';
			$item_styles['background-image']        = sprintf( 'url(%s)', esc_url($background_image) );
		}
		
		echo mane_elated_dynamic_css( '.eltdf-page-footer .eltdf-footer-bottom-holder', $item_styles );
		echo mane_elated_dynamic_css( '.eltdf-page-footer .eltdf-footer-bottom-holder:after', $pseudo_item_styles );
	}
	
	add_action( 'mane_elated_action_style_dynamic', 'mane_elated_footer_bottom_general_styles' );
}