<?php

include_once ELATED_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-divided/functions.php';
include_once ELATED_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-divided/header-divided.php';