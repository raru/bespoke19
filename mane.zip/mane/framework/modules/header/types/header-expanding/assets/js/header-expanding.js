(function($) {
    "use strict";

    var headerExpanding = {};
    eltdf.modules.headerExpanding = headerExpanding;

	headerExpanding.eltdfOnDocumentReady = eltdfOnDocumentReady;

    $(document).ready(eltdfOnDocumentReady);

    /* 
        All functions to be called on $(document).ready() should be in this function
    */
    function eltdfOnDocumentReady() {
	    eltdfExpandingMenu();
    }

	/**
	 * Init Expanding Menu
	 */
	function eltdfExpandingMenu() {

		if ($('a.eltdf-expanding-menu-opener').length) {

			var expandingMenuOpener = $( 'a.eltdf-expanding-menu-opener');

			// Open expanding menu
			expandingMenuOpener.on('click',function(e){
				e.preventDefault();

				if (!expandingMenuOpener.hasClass('eltdf-fm-opened')) {
					expandingMenuOpener.addClass('eltdf-fm-opened');
					eltdf.body.addClass('eltdf-expanding-menu-opened');
					$(document).keyup(function(e){
						if (e.keyCode == 27 ) {
							expandingMenuOpener.removeClass('eltdf-fm-opened');
							eltdf.body.removeClass('eltdf-expanding-menu-opened');
						}
					});
				} else {
					expandingMenuOpener.removeClass('eltdf-fm-opened');
					eltdf.body.removeClass('eltdf-expanding-menu-opened');
				}
			});
		}
	}

})(jQuery);