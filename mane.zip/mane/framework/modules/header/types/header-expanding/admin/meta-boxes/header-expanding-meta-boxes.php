<?php

if ( ! function_exists( 'mane_elated_get_hide_dep_for_header_expanding_meta_boxes' ) ) {
	function mane_elated_get_hide_dep_for_header_expanding_meta_boxes() {
		$hide_dep_options = apply_filters( 'mane_elated_header_expanding_hide_meta_boxes', $hide_dep_options = array() );
		
		return $hide_dep_options;
	}
}

if ( ! function_exists( 'mane_elated_header_expanding_meta_map' ) ) {
	function mane_elated_header_expanding_meta_map( $parent ) {
		$hide_dep_options = mane_elated_get_hide_dep_for_header_expanding_meta_boxes();

		mane_elated_add_meta_box_field(
			array(
				'parent'          => $parent,
				'type'            => 'select',
				'name'            => 'eltdf_expanding_menu_paspartout_triangle_meta',
				'default_value'   => 'no',
				'label'           => esc_html__( 'Enable Paspartout Triangle', 'mane' ),
				'description'     => esc_html__( 'Choose to display paspartout triangle around the "hamburger menu icon". Works with Expanding header', 'mane' ),
				'options'         => mane_elated_get_yes_no_select_array(false),
				'hidden_property' => 'header_type',
				'hidden_values'   => $hide_dep_options
			)
		);

		mane_elated_add_meta_box_field(
			array(
				'parent'        => $parent,
				'name'          => 'eltdf_expanding_menu_opener_color_meta',
				'type'          => 'yesno',
				'default_value' => 'no',
				'label'         => esc_html__( 'Keep Menu Opener On Light/Dark Skin', 'mane' ),
				'description'   => esc_html__( 'Set yes to keep the main color of the expanding menu opener on light or dark header skin', 'mane' ),
				'hidden_property' => 'header_type',
				'hidden_values'   => $hide_dep_options
			)
		);
	}
	
	add_action( 'mane_elated_action_additional_header_area_meta_boxes_map', 'mane_elated_header_expanding_meta_map' );
}