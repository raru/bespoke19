<?php

include_once ELATED_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-expanding/functions.php';
include_once ELATED_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-expanding/header-expanding.php';