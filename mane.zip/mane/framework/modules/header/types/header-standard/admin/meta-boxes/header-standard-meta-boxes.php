<?php

if ( ! function_exists( 'mane_elated_get_hide_dep_for_header_standard_meta_boxes' ) ) {
	function mane_elated_get_hide_dep_for_header_standard_meta_boxes() {
		$hide_dep_options = apply_filters( 'mane_elated_filter_header_standard_hide_meta_boxes', $hide_dep_options = array() );
		
		return $hide_dep_options;
	}
}

if ( ! function_exists( 'mane_elated_header_standard_meta_map' ) ) {
	function mane_elated_header_standard_meta_map( $parent ) {
		$hide_dep_options = mane_elated_get_hide_dep_for_header_standard_meta_boxes();
		
		mane_elated_add_meta_box_field(
			array(
				'parent'          => $parent,
				'type'            => 'select',
				'name'            => 'eltdf_set_menu_area_position_meta',
				'default_value'   => '',
				'label'           => esc_html__( 'Choose Menu Area Position', 'mane' ),
				'description'     => esc_html__( 'Select menu area position in your header', 'mane' ),
				'options'         => array(
					''       => esc_html__( 'Default', 'mane' ),
					'left'   => esc_html__( 'Left', 'mane' ),
					'right'  => esc_html__( 'Right', 'mane' ),
					'center' => esc_html__( 'Center', 'mane' )
				),
				'hidden_property' => 'eltdf_header_type_meta',
				'hidden_values'   => $hide_dep_options
			)
		);
	}
	
	add_action( 'mane_elated_action_additional_header_area_meta_boxes_map', 'mane_elated_header_standard_meta_map' );
}