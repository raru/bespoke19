<?php

if ( ! function_exists( 'mane_elated_logo_meta_box_map' ) ) {
	function mane_elated_logo_meta_box_map() {
		
		$logo_meta_box = mane_elated_add_meta_box(
			array(
				'scope' => apply_filters( 'mane_elated_filter_set_scope_for_meta_boxes', array( 'page', 'post' ), 'logo_meta' ),
				'title' => esc_html__( 'Logo', 'mane' ),
				'name'  => 'logo_meta'
			)
		);
		
		mane_elated_add_meta_box_field(
			array(
				'name'        => 'eltdf_logo_image_meta',
				'type'        => 'image',
				'label'       => esc_html__( 'Logo Image - Default', 'mane' ),
				'description' => esc_html__( 'Choose a default logo image to display ', 'mane' ),
				'parent'      => $logo_meta_box
			)
		);
		
		mane_elated_add_meta_box_field(
			array(
				'name'        => 'eltdf_logo_image_dark_meta',
				'type'        => 'image',
				'label'       => esc_html__( 'Logo Image - Dark', 'mane' ),
				'description' => esc_html__( 'Choose a default logo image to display ', 'mane' ),
				'parent'      => $logo_meta_box
			)
		);
		
		mane_elated_add_meta_box_field(
			array(
				'name'        => 'eltdf_logo_image_light_meta',
				'type'        => 'image',
				'label'       => esc_html__( 'Logo Image - Light', 'mane' ),
				'description' => esc_html__( 'Choose a default logo image to display ', 'mane' ),
				'parent'      => $logo_meta_box
			)
		);
		
		mane_elated_add_meta_box_field(
			array(
				'name'        => 'eltdf_logo_image_sticky_meta',
				'type'        => 'image',
				'label'       => esc_html__( 'Logo Image - Sticky', 'mane' ),
				'description' => esc_html__( 'Choose a default logo image to display ', 'mane' ),
				'parent'      => $logo_meta_box
			)
		);
		
		mane_elated_add_meta_box_field(
			array(
				'name'        => 'eltdf_logo_image_mobile_meta',
				'type'        => 'image',
				'label'       => esc_html__( 'Logo Image - Mobile', 'mane' ),
				'description' => esc_html__( 'Choose a default logo image to display ', 'mane' ),
				'parent'      => $logo_meta_box
			)
		);
	}
	
	add_action( 'mane_elated_action_meta_boxes_map', 'mane_elated_logo_meta_box_map', 47 );
}