<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/sidebar/sidebar.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/sidebar/eltdf-custom-sidebar.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/sidebar/sidebar-functions.php';

//load global sidebar options
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/sidebar/admin/options-map/sidebar-map.php';

//load per page sidebar options
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/sidebar/admin/meta-boxes/sidebar-meta-boxes.php';