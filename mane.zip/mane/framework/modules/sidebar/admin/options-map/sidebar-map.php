<?php

if ( ! function_exists( 'mane_elated_sidebar_options_map' ) ) {
	function mane_elated_sidebar_options_map() {
		
		mane_elated_add_admin_page(
			array(
				'slug'  => '_sidebar_page',
				'title' => esc_html__( 'Sidebar Area', 'mane' ),
				'icon'  => 'fa fa-indent'
			)
		);
		
		$sidebar_panel = mane_elated_add_admin_panel(
			array(
				'title' => esc_html__( 'Sidebar Area', 'mane' ),
				'name'  => 'sidebar',
				'page'  => '_sidebar_page'
			)
		);
		
		mane_elated_add_admin_field( array(
			'name'          => 'sidebar_layout',
			'type'          => 'select',
			'label'         => esc_html__( 'Sidebar Layout', 'mane' ),
			'description'   => esc_html__( 'Choose a sidebar layout for pages', 'mane' ),
			'parent'        => $sidebar_panel,
			'default_value' => 'no-sidebar',
            'options'       => mane_elated_get_custom_sidebars_options()
		) );
		
		$mane_custom_sidebars = mane_elated_get_custom_sidebars();
		if ( count( $mane_custom_sidebars ) > 0 ) {
			mane_elated_add_admin_field( array(
				'name'        => 'custom_sidebar_area',
				'type'        => 'selectblank',
				'label'       => esc_html__( 'Sidebar to Display', 'mane' ),
				'description' => esc_html__( 'Choose a sidebar to display on pages. Default sidebar is "Sidebar"', 'mane' ),
				'parent'      => $sidebar_panel,
				'options'     => $mane_custom_sidebars,
				'args'        => array(
					'select2' => true
				)
			) );
		}
	}
	
	add_action( 'mane_elated_action_options_map', 'mane_elated_sidebar_options_map', 9 );
}