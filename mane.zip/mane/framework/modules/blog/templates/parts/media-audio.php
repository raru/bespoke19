<?php

mane_elated_get_module_template_part('templates/parts/image', 'blog', '', $params);
mane_elated_get_module_template_part('templates/parts/post-type/audio', 'blog', '', $params);