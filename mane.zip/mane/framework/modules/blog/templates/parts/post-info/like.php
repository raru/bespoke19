<?php if(mane_elated_core_plugin_installed()) { ?>
    <div class="eltdf-blog-like">
        <?php if( function_exists('mane_elated_get_like') ) mane_elated_get_like(); ?>
    </div>
<?php } ?>