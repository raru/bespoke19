<?php

mane_elated_get_module_template_part('templates/parts/post-type/gallery', 'blog', '', $params);