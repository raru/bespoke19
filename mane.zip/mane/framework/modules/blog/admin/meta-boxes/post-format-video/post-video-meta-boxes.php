<?php

if ( ! function_exists( 'mane_elated_map_post_video_meta' ) ) {
	function mane_elated_map_post_video_meta() {
		$video_post_format_meta_box = mane_elated_add_meta_box(
			array(
				'scope' => array( 'post' ),
				'title' => esc_html__( 'Video Post Format', 'mane' ),
				'name'  => 'post_format_video_meta'
			)
		);
		
		mane_elated_add_meta_box_field(
			array(
				'name'          => 'eltdf_video_type_meta',
				'type'          => 'select',
				'label'         => esc_html__( 'Video Type', 'mane' ),
				'description'   => esc_html__( 'Choose video type', 'mane' ),
				'parent'        => $video_post_format_meta_box,
				'default_value' => 'social_networks',
				'options'       => array(
					'social_networks' => esc_html__( 'Video Service', 'mane' ),
					'self'            => esc_html__( 'Self Hosted', 'mane' )
				),
				'args'          => array(
					'dependence' => true,
					'hide'       => array(
						'social_networks' => '#eltdf_eltdf_video_self_hosted_container',
						'self'            => '#eltdf_eltdf_video_embedded_container'
					),
					'show'       => array(
						'social_networks' => '#eltdf_eltdf_video_embedded_container',
						'self'            => '#eltdf_eltdf_video_self_hosted_container'
					)
				)
			)
		);
		
		$eltdf_video_embedded_container = mane_elated_add_admin_container(
			array(
				'parent'          => $video_post_format_meta_box,
				'name'            => 'eltdf_video_embedded_container',
				'hidden_property' => 'eltdf_video_type_meta',
				'hidden_value'    => 'self'
			)
		);
		
		$eltdf_video_self_hosted_container = mane_elated_add_admin_container(
			array(
				'parent'          => $video_post_format_meta_box,
				'name'            => 'eltdf_video_self_hosted_container',
				'hidden_property' => 'eltdf_video_type_meta',
				'hidden_value'    => 'social_networks'
			)
		);
		
		mane_elated_add_meta_box_field(
			array(
				'name'        => 'eltdf_post_video_link_meta',
				'type'        => 'text',
				'label'       => esc_html__( 'Video URL', 'mane' ),
				'description' => esc_html__( 'Enter Video URL', 'mane' ),
				'parent'      => $eltdf_video_embedded_container,
			)
		);
		
		mane_elated_add_meta_box_field(
			array(
				'name'        => 'eltdf_post_video_custom_meta',
				'type'        => 'text',
				'label'       => esc_html__( 'Video MP4', 'mane' ),
				'description' => esc_html__( 'Enter video URL for MP4 format', 'mane' ),
				'parent'      => $eltdf_video_self_hosted_container,
			)
		);
		
		mane_elated_add_meta_box_field(
			array(
				'name'        => 'eltdf_post_video_image_meta',
				'type'        => 'image',
				'label'       => esc_html__( 'Video Image', 'mane' ),
				'description' => esc_html__( 'Enter video image', 'mane' ),
				'parent'      => $eltdf_video_self_hosted_container,
			)
		);
	}
	
	add_action( 'mane_elated_action_meta_boxes_map', 'mane_elated_map_post_video_meta', 22 );
}