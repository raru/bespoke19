<?php

if ( ! function_exists( 'mane_elated_map_post_quote_meta' ) ) {
	function mane_elated_map_post_quote_meta() {
		$quote_post_format_meta_box = mane_elated_add_meta_box(
			array(
				'scope' => array( 'post' ),
				'title' => esc_html__( 'Quote Post Format', 'mane' ),
				'name'  => 'post_format_quote_meta'
			)
		);
		
		mane_elated_add_meta_box_field(
			array(
				'name'        => 'eltdf_post_quote_text_meta',
				'type'        => 'text',
				'label'       => esc_html__( 'Quote Text', 'mane' ),
				'description' => esc_html__( 'Enter Quote text', 'mane' ),
				'parent'      => $quote_post_format_meta_box,
			
			)
		);
		
		mane_elated_add_meta_box_field(
			array(
				'name'        => 'eltdf_post_quote_author_meta',
				'type'        => 'text',
				'label'       => esc_html__( 'Quote Author', 'mane' ),
				'description' => esc_html__( 'Enter Quote author', 'mane' ),
				'parent'      => $quote_post_format_meta_box,
			)
		);
	}
	
	add_action( 'mane_elated_action_meta_boxes_map', 'mane_elated_map_post_quote_meta', 25 );
}