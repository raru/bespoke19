<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/woocommerce/shortcodes/product-list-simple/functions.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/woocommerce/shortcodes/product-list-simple/product-list-simple.php';