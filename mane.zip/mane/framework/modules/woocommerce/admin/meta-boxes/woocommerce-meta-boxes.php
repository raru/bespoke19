<?php

if(!function_exists('mane_elated_map_woocommerce_meta')) {
    function mane_elated_map_woocommerce_meta() {
        $woocommerce_meta_box = mane_elated_add_meta_box(
            array(
                'scope' => array('product'),
                'title' => esc_html__('Product Meta', 'mane'),
                'name' => 'woo_product_meta'
            )
        );

        mane_elated_add_meta_box_field(array(
            'name'        => 'eltdf_product_featured_image_size',
            'type'        => 'select',
            'label'       => esc_html__('Dimensions for Product List Shortcode', 'mane'),
            'description' => esc_html__('Choose image layout when it appears in Elated Product List - Masonry layout shortcode', 'mane'),
            'parent'      => $woocommerce_meta_box,
            'options'     => array(
                'eltdf-woo-image-normal-width' => esc_html__('Default', 'mane'),
                'eltdf-woo-image-large-width'  => esc_html__('Large Width', 'mane')
            )
        ));

        mane_elated_add_meta_box_field(
            array(
                'name'          => 'eltdf_show_title_area_woo_meta',
                'type'          => 'select',
                'default_value' => '',
                'label'         => esc_html__('Show Title Area', 'mane'),
                'description'   => esc_html__('Disabling this option will turn off page title area', 'mane'),
                'parent'        => $woocommerce_meta_box,
                'options'       => mane_elated_get_yes_no_select_array()
            )
        );
    }
	
    add_action('mane_elated_action_meta_boxes_map', 'mane_elated_map_woocommerce_meta', 99);
}