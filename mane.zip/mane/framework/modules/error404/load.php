<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/error404/options-map/map.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/error404/custom-styles/custom-styles.php';